package rabbitmq;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.AMQP.Queue.DeclareOk;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

public class SimpleWithAllDefaults {

	public static void main(String[] args) throws Exception {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost("localhost");
		factory.setUsername("guest");
		factory.setPassword("guest");
		Connection connection = factory.newConnection();
		final Channel channel = connection.createChannel();// channel holds a
															// socket connection
															// with the server
															// in realtime;
		// this helps in server to autodelete queues when channel.close() is
		// called or when the program running holding the reference to channel
		// terminates.
		
		
		//channel.basicQos(1);// set the no of msgs to download at a time.
		// setting it to a high value is useless, they all accumulate at the
		// consumer.
		// if the consumer is crashes all those msgs are gone.
		
		
		/**
		 * Durable (the queue will still be alive after the server restart)
		 * Exclusive (used by only one connection and the queue will be deleted
		 * when that connection closes). i.e both sender&receiver should use the same connection ref. If the consumer tries to connect to the 
		 * same q using another connection u get "cannot obtain exclusive access to locked queue" error. when u say channelFromNewConn.queueDeclare(..) 
		 * Auto-delete (queue that has had at least
		 * one consumer is deleted when last consumer unsubscribes) More on this
		 * here: https://www.rabbitmq.com/queues.html
		 */
		
		DeclareOk queue = channel.queueDeclare();
		// autogenerates a q with random name ex: amq.gen-YqU9H-TjZj0qNJi9wSGqEg
		// which is exclusive, autodelete, non-durable queue.
		// Declaring a queue is idempotent - it will only be created if it
		// doesn't exist already.
		//more on this here: https://stackoverflow.com/questions/21248563/rabbitmq-difference-between-exclusive-and-auto-delete
		String qName = queue.getQueue();
		System.out.println(qName);

		// args:String exchangeName, String routingKey, BasicProperties props,
		// byte[] body)
		// passing exchangeName as null results in : Invalid configuration error: 'exchange' must be non-null.
		// passing routingKey as null results in :'routingKey' must be non-null error.
		//sending a msg to a non existent Q, will not result any error. Simply it will be lost!
		channel.basicPublish("", "rk1", null, "m1".getBytes()); // creates a
																// default
																// exchange (i.e
																// with name ""
																// and binds the
																// queue with
																// this exchange
																// with no
																// routing key.
		//the above msg will just be ignored, because you have not mapped the Q with the channel yet!
		//this can be done either by channel.bind or directly give the queName in the placeof "routingKey" (2arg of basicPublish) as follows:
		channel.basicPublish("", qName, null, "m2".getBytes());
		channel.basicPublish("", qName, null, "m3".getBytes()); 
		channel.basicPublish("", qName, null, "m4".getBytes());
		channel.basicPublish("", qName, null, "m5".getBytes());
		channel.basicPublish("", qName, null, "m6".getBytes());

		// CONSUMERs
		// yes we can use the same channel to both prodce and consume messages.
		channel.basicConsume(qName, new DefaultConsumer(channel) {
			public void handleDelivery(String consumerTag, Envelope envelope,
					AMQP.BasicProperties properties, byte[] body) {
				try {
					System.out.println("11111 " + new String(body, "UTF-8"));
					Thread.sleep(5000);
					// channel.basicAck(envelope.getDeliveryTag(), false);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		// this can never receive the msg (if this is registered after the
		// sender sends messages to Queue, all messages are consumed by the
		// consumer already defined before. Its BECOZ, bydefault
		// prefetchcount=unlimited & autoack=false, so all the messages will be
		// downloaded by the 1st consumer they will be in unack state forever
		// eventhough consumer finishes processing all messages one by one.
		// so, 2nd will never get them.. But, when
		// the 2 consumers are registered to the server for the same Q before
		// the sender sends the msgs, rabbit
		// always makes sure that it shares the nth msg with the nth consumer!

		// In your usecase, if there is no gaurantee that all the consumers will
		// be regisrted to the server before hand,
		// and they may connect and go off at any time (ex: developre may connect to
		// server at any time while doing dev work!),
		// and you still want the server to distrubute the msgs in RR fashion,
		// i.e if 3 messages come, 1st willl be sent 1st consumer, 2 will be
		// sent 2nd consumer, 3 will be sent 1st..so on..
		// then u must set prefetchcount=1 and auack=false and manually ack the
		// msg after finishing channel.basicAck(envelope.getDeliveryTag(),
		// false)
		// if any of the 2 are not set, then it will not work.
		// i.e if u only set prefetchcount=1 then all msgs will be accumulated in the Q which we want. next, the 1st
		// consumer recieves 1 and 2nd consumer recives one
		// and the remaining msgs are not consumed by them bcoz, autoack
		// bydefault is false. Note that as long as a consumer
		// does not acknowledge the next msg will not be sent(bcoz prefetch=1)
		// or if preftech is not set also, its handleDelivery
		// is not called until it sends ack. All the downloaded msgs are
		// downloaded and only 1 msg is processed.
		channel.basicConsume(qName, new DefaultConsumer(channel) {
			public void handleDelivery(String consumerTag, Envelope envelope,
					AMQP.BasicProperties properties, byte[] body) {
				try {
					System.out.println("22222 " + new String(body, "UTF-8"));
					Thread.sleep(5000);
					// channel.basicAck(envelope.getDeliveryTag(), false);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
		// channel.close(); //this makes sure that the Q is autodeleted.

	}

}
