package rabbitmq;

import java.io.IOException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
/**
 * output:
 *   [*] Waiting for messages. To exit press CTRL+C
	 [*] Waiting for messages. To exit press CTRL+C
	 [*] Waiting for messages. To exit press CTRL+C
	 [x] Received 'm1' consumer: key1
	 [x] Received 'm2' consumer: key2
	 [x] Received 'm3' consumer: key3
 * @author HP PC
 *
 */
public class Direct extends RabbitManager {
	private static final String EXCHANGE_NAME = "direct_exchange_1";

	public static void main(String[] args) throws Exception {
		Direct d = new Direct();
		d.startConsumer("key1");
		d.startConsumer("key2");
		d.startConsumer("key3");
		
		d.startProducer("m1","key1");
		d.startProducer("m2","key2");
		d.startProducer("m3","key3");
		//d.startProducer("m4",null); //error: 'routingKey' must be non-null.
		d.startProducer("m5","");
		
	}

	public void startProducer(String msg, String routingKey) throws Exception {
		Channel channel = getSession();
		channel.exchangeDeclare(EXCHANGE_NAME, "direct");//exchange name can neither be null nor default "".
		channel.basicPublish(EXCHANGE_NAME, routingKey, null, msg.getBytes());//incase of simple, client is sending msg to default exchange, which is binded to 1 single Q.
		channel.close();
	}

	public void startConsumer(final String routingKey) throws Exception {
		Channel channel = getSession();
		channel.exchangeDeclare(EXCHANGE_NAME, "direct");
		String queueName = channel.queueDeclare().getQueue();//having a q shared to multiple consumers, is like wrker queues.
		channel.queueBind(queueName, EXCHANGE_NAME, routingKey);

		System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

		Consumer consumer = new DefaultConsumer(channel) {
			@Override
			public void handleDelivery(String consumerTag, Envelope envelope,
					AMQP.BasicProperties properties, byte[] body)
					throws IOException {
				String message = new String(body, "UTF-8");
				System.out.println(" [x] Received '" + message + "' consumer: " + routingKey);
			}
		};
		channel.basicConsume(queueName, true, consumer);
		//channel.close();
	}

}
