package rabbitmq;

import java.io.IOException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
/**
 * Direct -> only 1 queue -> many consumers connected to the same queue.
 * As you can see from the op, it works same as \SimpleWithAllDefaults.java
 * The exchange blindly delivers all msgs to the Queue. We see that many consumers r connected to the same Q,
 * So rabbit kicks in its default approch: send nth msg to nth consumer!
 * output:
 *   [*] Waiting for messages. To exit press CTRL+C
	 [*] Waiting for messages. To exit press CTRL+C
	 [*] Waiting for messages. To exit press CTRL+C
	 [x] Received 'm1'by consumer: c1
	 [x] Received 'm2'by consumer: c2
	 [x] Received 'm3'by consumer: c3
	 [x] Received 'm4'by consumer: c1
	 [x] Received 'm5'by consumer: c2
	 [x] Received 'm6'by consumer: c3

 * @author HP PC
 *
 */
public class FanoutOneQueueMultipleConsumers extends RabbitManager {
	private static final String EXCHANGE_NAME = "logs";

	public static void main(String[] args) throws Exception {
		FanoutOneQueueMultipleConsumers f = new FanoutOneQueueMultipleConsumers();
		f.startConsumer("c1");
		f.startConsumer("c2");
		f.startConsumer("c3"); // Note that consumers must be declared before
								// producing messages, otherwise exchange thinks
								// that there are no queues binded to it and
								// discards them off, those msgs are gone!
		
		f.startProducer("m1");
		f.startProducer("m2");
		f.startProducer("m3");
		f.startProducer("m4");
		f.startProducer("m5");
		f.startProducer("m6");
		
		
		
	}

	public void startProducer(String msg) throws Exception {
		Channel channel = getSession();
		channel.exchangeDeclare(EXCHANGE_NAME, "fanout");//exchange name can neither be null nor default "".
		channel.basicPublish(EXCHANGE_NAME, "", null, msg.getBytes());//incase of simple, client is sending msg to default exchange, which is binded to 1 single Q.
		channel.close();
	}

	public void startConsumer(final String consumerId) throws Exception {
		Channel channel = getSession();
		channel.exchangeDeclare(EXCHANGE_NAME, "fanout");
		String queueName = channel.queueDeclare("fanout_only_one_queue",false,false,true,null).getQueue();
		channel.queueBind(queueName, EXCHANGE_NAME, "");

		System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

		Consumer consumer = new DefaultConsumer(channel) {
			@Override
			public void handleDelivery(String consumerTag, Envelope envelope,
					AMQP.BasicProperties properties, byte[] body)
					throws IOException {
				String message = new String(body, "UTF-8");
				System.out.println(" [x] Received '" + message + "'" + "by consumer: " + consumerId);
			}
		};
		channel.basicConsume(queueName, true, consumer);
		//channel.close();
	}

}
