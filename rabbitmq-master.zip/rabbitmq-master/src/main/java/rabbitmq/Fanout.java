package rabbitmq;

import java.io.IOException;

import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;

/**
 *   [*] Waiting for messages. To exit press CTRL+C
	 [*] Waiting for messages. To exit press CTRL+C
	 [*] Waiting for messages. To exit press CTRL+C
	 [x] Received 'm1'
	 [x] Received 'm1'
	 [x] Received 'm1'
	 [x] Received 'm2'
	 [x] Received 'm2'
	 [x] Received 'm2'
	 [x] Received 'm3'
	 [x] Received 'm3'
	 [x] Received 'm3'
	 [x] Received 'm4'
	 [x] Received 'm4'
	 [x] Received 'm4'
	 [x] Received 'm5'
	 [x] Received 'm5'
	 [x] Received 'm5'
	 [x] Received 'm6'
	 [x] Received 'm6'
	 [x] Received 'm6'

 * @author HP PC
 *
 */

public class Fanout extends RabbitManager {
	private static final String EXCHANGE_NAME = "logs";

	public static void main(String[] args) throws Exception {
		Fanout f = new Fanout();
		f.startConsumer();
		f.startConsumer();
		f.startConsumer(); // Note that consumers must be declared before
							// producing messages, otherwise exchange thinks
							// that there are no queues binded to it and
							// discards them off, those msgs are gone!
		
		f.startProducer("m1");
		f.startProducer("m2");
		f.startProducer("m3");
		f.startProducer("m4");
		f.startProducer("m5");
		f.startProducer("m6");
	}

	public void startProducer(String msg) throws Exception {
		Channel channel = getSession();
		channel.exchangeDeclare(EXCHANGE_NAME, "fanout");//exchange name can neither be null nor default "".
		channel.basicPublish(EXCHANGE_NAME, "", null, msg.getBytes());//incase of simple, client is sending msg to default exchange, which is binded to 1 single Q.
		channel.close();
	}

	public void startConsumer() throws Exception {
		Channel channel = getSession();
		channel.exchangeDeclare(EXCHANGE_NAME, "fanout");
		String queueName = channel.queueDeclare().getQueue();//having a q shared to multiple consumers, is like wrker queues.
		channel.queueBind(queueName, EXCHANGE_NAME, "");

		System.out.println(" [*] Waiting for messages. To exit press CTRL+C");

		Consumer consumer = new DefaultConsumer(channel) {
			@Override
			public void handleDelivery(String consumerTag, Envelope envelope,
					AMQP.BasicProperties properties, byte[] body)
					throws IOException {
				String message = new String(body, "UTF-8");
				System.out.println(" [x] Received '" + message + "'");
			}
		};
		channel.basicConsume(queueName, true, consumer);
		//channel.close();
	}

}
