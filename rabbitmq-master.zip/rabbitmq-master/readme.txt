https://www.rabbitmq.com/api-guide.html
https://www.rabbitmq.com/tutorials/tutorial-one-java.html